package org.example.frameworkmvc2;

import java.io.Serializable;

public class UserBean implements Serializable {
    private String username;
    private boolean valid;

    public UserBean() {
        this.valid = false; // Par défaut, l'utilisateur n'est pas connecté
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public boolean isValid() {
        return valid;
    }

    public void setValid(boolean valid) {
        this.valid = valid;
    }
}
