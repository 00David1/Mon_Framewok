package org.example.frameworkmvc2;

import java.util.HashMap;
import java.util.Map;

public class MyFactory {
    private static Map<String, Class<? extends Action>> actions = new HashMap<>();

    static {
        // On remplie manuellement la Map
        actions.put("/login.do", LoginAction.class);
        actions.put("/logout.do", LogoutAction.class);
        actions.put("/actionUn.do", ActionUn.class);
    }

    public static Action getAction(String provenance) {
        Class<? extends Action> actionClass = actions.get(provenance);
        if (actionClass != null) {
            try {
                return actionClass.getDeclaredConstructor().newInstance();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return null;
    }
}
