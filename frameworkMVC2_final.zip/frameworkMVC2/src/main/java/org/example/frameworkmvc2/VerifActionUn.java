package org.example.frameworkmvc2;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class VerifActionUn implements Action {

    @Override
    public String performe(HttpServletRequest request, HttpServletResponse response) {
        String attribut2 = request.getParameter("Attribut2");
        String attribut3 = request.getParameter("Attribut3");

        System.out.println("Attribut2: " + attribut2);
        System.out.println("Attribut3: " + attribut3);

        if ("".equals(attribut2) || "".equals(attribut3)) {
            return "page1.jsp";
        }
        return "page1.jsp";
    }
}


