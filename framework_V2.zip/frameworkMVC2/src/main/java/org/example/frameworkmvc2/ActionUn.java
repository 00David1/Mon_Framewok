package org.example.frameworkmvc2;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

public class ActionUn implements Action {
    @Override
    public String performe(HttpServletRequest request, HttpServletResponse response) {
        String attribut2 = request.getParameter("Attribut2");
        String attribut3 = request.getParameter("Attribut3");

        System.out.println("Attribut2: " + attribut2);
        System.out.println("Attribut3: " + attribut3);

        return "page1.jsp";
    }
}
