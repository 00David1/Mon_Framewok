package org.example.frameworkmvc2;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;


public class DispatcherServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    private void processRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String provenance = request.getServletPath();

        Action action = MyFactory.getAction(provenance);

        if (action != null) {
            String destination = action.performe(request, response);
            response.sendRedirect(destination);
        } else {
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Action inconnue : " + provenance);
        }
    }
}
