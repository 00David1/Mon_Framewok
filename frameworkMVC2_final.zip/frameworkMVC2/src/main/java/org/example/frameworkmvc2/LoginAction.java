package org.example.frameworkmvc2;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

public class LoginAction implements Action {
    @Override
    public String performe(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        if ("admin".equals(username) && "1234".equals(password)) {
            UserBean user = new UserBean();
            user.setUsername(username);
            user.setValid(true);

            HttpSession session = request.getSession();
            session.setAttribute("user", user);

            return "page1.jsp";
        } else {
            return "erreur.jsp";
        }
    }
}
