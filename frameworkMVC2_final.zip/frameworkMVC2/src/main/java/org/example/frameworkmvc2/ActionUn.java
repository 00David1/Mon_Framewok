package org.example.frameworkmvc2;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class ActionUn implements Action {

    @Override
    public String performe(HttpServletRequest request, HttpServletResponse response) {
        String attribut2 = request.getParameter("Attribut2");
        String attribut3 = request.getParameter("Attribut3");

        // Traitement métier, ici juste affichage ou stockage
        request.setAttribute("Attribut2", attribut2);
        request.setAttribute("Attribut3", attribut3);

        System.out.println("Attribut2: " + attribut2);
        System.out.println("Attribut3: " + attribut3);

        return "attributPlein.jsp";
    }
}
