package org.example.frameworkmvc2;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@WebServlet("*.do")
public class DispatcherServlet extends HttpServlet {
    private Map<String, Action> actions = new HashMap<>();

    @Override
    public void init() throws ServletException {
        actions.put("/login.do", new LoginAction());
        actions.put("/logout.do", new LogoutAction());
        actions.put("/actionUn.do", new ActionUn());
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }

    private void processRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String path = request.getServletPath();
        Action action = actions.get(path);

        if (action != null) {
            String destination = action.performe(request, response);
            response.sendRedirect(destination);
        } else {
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Action inconnue : " + path);
        }
    }
}
