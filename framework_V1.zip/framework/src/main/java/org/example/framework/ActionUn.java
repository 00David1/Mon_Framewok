package org.example.framework;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/actionUn")
public class ActionUn extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Récupération des paramètres du formulaire
        String attribut2 = request.getParameter("Attribut2");
        String attribut3 = request.getParameter("Attribut3");

        // Affichage des valeurs dans la console
        System.out.println("Attribut2: " + attribut2);
        System.out.println("Attribut3: " + attribut3);

        // Redirection vers page1.jsp
        response.sendRedirect("page1.jsp");
    }
}
