package org.example.framework;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/login")
public class HelloServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Simuler un utilisateur valide (tu peux connecter ça à une BDD)
        if ("admin".equals(username) && "1234".equals(password)) {
            UserBean user = new UserBean();
            user.setUsername(username);
            user.setValid(true);

            // Stocker le bean dans la session
            HttpSession session = request.getSession();
            session.setAttribute("user", user);

            // Rediriger vers page1.jsp
            response.sendRedirect("page1.jsp");
        } else {
            // Rediriger vers erreur.jsp si login incorrect
            response.sendRedirect("erreur.jsp");
        }
    }
}
