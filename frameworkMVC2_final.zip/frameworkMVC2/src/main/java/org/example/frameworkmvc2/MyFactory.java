package org.example.frameworkmvc2;

import org.w3c.dom.*;
import javax.xml.parsers.*;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class MyFactory {
    private static Map<String, Class<? extends Action>> actions = new HashMap<>();

    static {
        try {
            InputStream inputStream = MyFactory.class.getClassLoader().getResourceAsStream("MyFactory.xml");
            if (inputStream == null) {
                throw new RuntimeException("Fichier xml introuvable !");
            }

            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(inputStream);

            NodeList actionNodes = doc.getElementsByTagName("action");

            for (int i = 0; i < actionNodes.getLength(); i++) {
                Element actionElement = (Element) actionNodes.item(i);
                String path = actionElement.getAttribute("path");
                String className = actionElement.getAttribute("class");

                Class<?> clazz = Class.forName(className);
                if (Action.class.isAssignableFrom(clazz)) {
                    actions.put(path, (Class<? extends Action>) clazz);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Action getAction(String provenance) {
        Class<? extends Action> actionClass = actions.get(provenance);
        if (actionClass != null) {
            try {
                return actionClass.getDeclaredConstructor().newInstance();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return null;
    }
}
