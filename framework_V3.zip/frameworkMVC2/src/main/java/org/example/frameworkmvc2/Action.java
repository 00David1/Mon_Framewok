package org.example.frameworkmvc2;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

public interface Action {
    String performe(HttpServletRequest request, HttpServletResponse response) throws IOException;
}

